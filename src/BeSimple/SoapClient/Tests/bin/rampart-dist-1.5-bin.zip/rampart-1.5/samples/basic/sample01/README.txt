Rampart Engaged and no configuration

This sample shows that Apache Rampart does not work on the messages when simply
engagd without any configuration

Note: <module ref="rampart"/> in both client.axis2.xml and services.xml
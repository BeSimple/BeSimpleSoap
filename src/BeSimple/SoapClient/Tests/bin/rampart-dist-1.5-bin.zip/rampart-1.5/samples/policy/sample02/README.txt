Sign only

An AsymmetricBinding is used. Entire headers and body to be signed.
Algorithm suite is TripleDesRsa15

Note that {http://ws.apache.org/rampart/policy}RampartConfig assertion provides
additional information required to secure the message.
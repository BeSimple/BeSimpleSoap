WS-Trust - RST - Resquest Security Token Service - Issuing a SAML 2.0 token - issuing a token

When using this sample with the TCPMon to monitor the soap messages, you have to use the 
correct URL in the client code before build the sample 08.

You have to endorse the default JAXP implementation of your JDK before invoking this sample.
Please follow the instructions available in the README.txt of this distribution to endorse 
the default JAXP implementation.

WS-Trust ( With WS Metada Exchange) - RST - Resquest Security Token Service - Issuing a SAML token - issuing a token

When using this sample with the TCPMon to monitor the soap messages, you have to use the 
correct URL in the client code before build the sample 05. 

